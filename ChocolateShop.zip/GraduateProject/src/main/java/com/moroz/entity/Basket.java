package com.moroz.entity;

public class Basket {
}
