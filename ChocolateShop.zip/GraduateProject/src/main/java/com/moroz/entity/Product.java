package com.moroz.entity;

public class Product {
}
