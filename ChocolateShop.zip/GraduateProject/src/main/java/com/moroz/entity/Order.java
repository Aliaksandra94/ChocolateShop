package com.moroz.entity;

public class Order {
}
