package com.moroz.entity;

public class BasketItem {
}
